README.TXT

The org.apache.commons.io bundle is a simple repackaging of the commons-io-1.2.jar as an eclipse plugin.
It is included in Jazz Foundation to satisfy dependencies from the repository service and Apache HTTP client
among others.